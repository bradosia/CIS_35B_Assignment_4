package adapter;

import scale.Scaleable;

/*
 * Assignment 4: we have added the scale package
 * which contains an interface Scaleable
 */
public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto, ChooseAuto, scale.Scaleable {

}
